import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class CarruselFrases extends StatelessWidget {
  final List<String> frases = [
    "''Covierte tus likes en risas''",
    "''Cada like es una pista''",
    "''Tus likes dicen mucho de ti''",
    "¿Quién fue el del like?",
  ];

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(
        autoPlay: true,
        autoPlayInterval: const Duration(seconds: 5),
        height: 80,
        enlargeCenterPage: true,
      ),
      items: frases.map((frase) {
        return Center(
          child: Text(
            frase,
            style: const TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        );
      }).toList(),
    );
  }
}
