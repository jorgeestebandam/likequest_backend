import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class CarruselFotos extends StatefulWidget {
  const CarruselFotos({super.key});

  @override
  State<CarruselFotos> createState() => _carruselFotos();
}

class _carruselFotos extends State<CarruselFotos> {
  List<String> imageList = [
    'assets/images/foto1.png',
    'assets/images/foto2.png',
    'assets/images/foto3.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Center(
      child: CarouselSlider(
        items: imageList
            .map(
              (item) => Container(
                margin: EdgeInsets.all(2.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
                  image: DecorationImage(
                    image: AssetImage(item),
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            )
            .toList(),
        options: CarouselOptions(
          height: 420.0,
          autoPlay: true,
          autoPlayInterval: Duration(seconds: 3),
          autoPlayAnimationDuration: Duration(milliseconds: 800),
          enlargeCenterPage: true,
          enlargeFactor: 0.25,
          aspectRatio: 16 / 9,
          viewportFraction: 0.92,
        ),
      ),
    );
  }
}
