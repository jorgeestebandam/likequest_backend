import 'dart:async';

import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/screens/game_setup_screen.dart';
import 'package:like_quest_flutter/screens/settings_party_screen.dart';
import 'package:like_quest_flutter/services/party_service.dart';

class CodigoSalaWidget extends StatefulWidget {
  final String pin;
  final User user;
  const CodigoSalaWidget({super.key, required this.pin, required this.user});

  @override
  State<CodigoSalaWidget> createState() => _CodigoSalaWidget();
}

class _CodigoSalaWidget extends State<CodigoSalaWidget> {
  List<String> jugadores = [];
  PartyService partyService = PartyService();
  Timer? _timer;
  Timer? _estadoTimer;
  String creador = "";
  bool _cargandoCreador = true;

  @override
  void initState() {
    super.initState();
    _startFetchingPlayers();
    _fetchCreador().then((value) {
      if (mounted) {
        setState(() {
          creador = value;
          _cargandoCreador = false;
        });
        _startCheckingEstado();
      }
    });
  }

  void _startCheckingEstado() {
    _estadoTimer = Timer.periodic(Duration(seconds: 2), (timer) async {
      try {
        if (widget.user.username == creador) return;
        final estado = await partyService.getEstadoPartida(widget.pin);
        if (!mounted) return;
        if (estado == "jugando") {
          timer.cancel();
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (_) => GameSetupScreen(
                pin: widget.pin,
                user: widget.user,
                creador: creador,
              ),
            ),
          );
        }
      } catch (e) {
        print("Error comprobando estado: $e");
      }
    });
  }

  void _startFetchingPlayers() {
    _timer = Timer.periodic(Duration(seconds: 2), (timer) async {
      final nuevosJugadores = await partyService.fetchJugadores(widget.pin);
      if (!mounted) return;
      setState(() {
        jugadores = nuevosJugadores;
      });
    });
  }

  Future<void> _iniciarPartida() async {
    try {
      await partyService.iniciarPartida(widget.pin);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => GameSetupScreen(
            pin: widget.pin,
            user: widget.user,
            creador: creador,
          ),
        ),
      );
    } catch (error) {
      print("Error al iniciar la partida: $error");
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _estadoTimer?.cancel();
    super.dispose();
  }

  Future<String> _fetchCreador() async {
    String creador = await partyService.getCreatorParty(widget.pin);
    return creador;
  }

  @override
  Widget build(BuildContext context) {
    // Mientras carga el creador mostramos un spinner
    if (_cargandoCreador) {
      return const Center(child: CircularProgressIndicator());
    }

    bool haySuficientesJugadores = jugadores.length > 2;
    bool esCreador = widget.user.username == creador;

    return Column(
      children: [
        // ── Botón settings (solo creador) ─────────────────────
        if (esCreador)
          SizedBox(
            width: double.infinity,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  icon: const Icon(Icons.settings),
                  color: const Color(0xFF929191),
                  iconSize: 50,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => SeetingPartyScreen(pin: widget.pin),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

        const SizedBox(height: 20),

        // ── Código de sala ─────────────────────────────────────
        Text(
          "Tu código de sala es:",
          style: TextStyle(color: AppColors.backgroundColorTexts, fontSize: 15),
        ),
        Text(
          widget.pin,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 40),
        ),
        const SizedBox(height: 30),

        // ── Lista de jugadores ─────────────────────────────────
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xA16A0DAD),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  if (jugadores.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Text(
                        "Aquí se irán uniendo los jugadores...",
                        textAlign: TextAlign.center,
                      ),
                    ),
                  if (jugadores.isNotEmpty) ...[
                    const Text(
                      "¡Todo está listo!",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      "Jugadores unidos: ${jugadores.length}",
                      style: const TextStyle(fontSize: 16, color: Colors.white),
                    ),
                    const SizedBox(height: 16),
                    Expanded(
                      child: ListView.builder(
                        itemCount: jugadores.length,
                        itemBuilder: (context, index) {
                          final jugador = jugadores[index];
                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            padding: const EdgeInsets.symmetric(
                              vertical: 8,
                              horizontal: 16,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white24,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: Text(
                                jugador,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),

        // ── Texto espera (solo jugadores) ──────────────────────
        if (!esCreador)
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              "Esperando a que el anfitrión inicie la partida...",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: const Color(0xB30C0C0C),
                fontSize: 16,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),

        const SizedBox(height: 16),

        // ── Botón comenzar (solo creador con suficientes jugadores) ──
        if (esCreador && haySuficientesJugadores)
          SizedBox(
            width: 200,
            height: 70,
            child: ElevatedButton(
              onPressed: _iniciarPartida,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.backgroundAppBar,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Comenzar partida',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),

        const SizedBox(height: 16),
      ],
    );
  }
}
