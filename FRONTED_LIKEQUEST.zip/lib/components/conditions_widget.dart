import 'package:flutter/material.dart';
import 'package:like_quest_flutter/components/carrusel_fotos_widget.dart';
import 'package:like_quest_flutter/core/color.dart';

class ConditionsWidget extends StatefulWidget {
  const ConditionsWidget({super.key});

  @override
  State<ConditionsWidget> createState() => _ConditionsWidget();
}

class _ConditionsWidget extends State<ConditionsWidget> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        physics: ClampingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 40),
            Text(
              "Términos y Condiciones",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                backgroundColor: AppColors.backgroundColorTexts,
              ),
            ),
            SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                "Para poder jugar, es necesario que tus likes de TikTok estén configurados como públicos.",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                "Ajustes y privacidad > Privacidad > Videos que te han gustado > Todo el mundo",
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 450,
              child: CarruselFotos(),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
