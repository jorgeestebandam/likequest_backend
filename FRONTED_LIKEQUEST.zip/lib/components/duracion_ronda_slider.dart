import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/core/text.dart';

class RondasDuracionSlider extends StatefulWidget {
  final Function(double)? onValueChanged;
  const RondasDuracionSlider({super.key, this.onValueChanged});

  @override
  State<RondasDuracionSlider> createState() => _RondasDuracionSlider();
}

class _RondasDuracionSlider extends State<RondasDuracionSlider> {
  double duracionRonda = 30;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.secondary,
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "TIEMPO DE ELECCIÓN",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 8),
            Text(
              "${duracionRonda.toStringAsFixed(0)} sec",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            Slider(
              value: duracionRonda,
              onChanged: (newValue) {
                setState(() {
                  duracionRonda = newValue;
                });
                widget.onValueChanged?.call(newValue);
              },
              min: 30,
              max: 60,
              divisions: 20,
              label: "${duracionRonda.toStringAsFixed(0)}",
            ),
          ],
        ),
      ),
    );
  }
}