import 'package:flutter/material.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/screens/create_party_screen.dart';
import 'package:like_quest_flutter/screens/join_party_screen.dart';
import 'package:like_quest_flutter/services/party_service.dart';

class GameSelector extends StatefulWidget {
  final User user;
  const GameSelector({super.key, required this.user});

  @override
  State<GameSelector> createState() => _GameSelectorState();
}

class _GameSelectorState extends State<GameSelector> {
  String? gameSelcted;
  final PartyService _partyService = PartyService();

  // Widget reutilizable para cada opción
  Widget _buildOptionCard({
    required String label,
    required IconData icon,
    required String key,
    required VoidCallback onTap,
  }) {
    final bool isSelected = gameSelcted == key;

    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.only(
            left: key == "crear" ? 16 : 8,
            top: 16,
            bottom: 16,
            right: key == "crear" ? 8 : 16,
          ),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 120,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isSelected
                    ? [const Color(0xFFC31BC6), const Color(0xFF8B00A0)]
                    : [const Color(0xFFF67DCA), const Color(0xFFE05BB5)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: isSelected
                      ? const Color(0xFFC31BC6).withOpacity(0.5)
                      : Colors.black.withOpacity(0.15),
                  blurRadius: isSelected ? 12 : 6,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  // ✅ Morado oscuro cuando no está seleccionado, blanco cuando sí
                  color: isSelected ? Colors.white : const Color(0xFF4A0060),
                  size: 32,
                ),
                const SizedBox(height: 10),
                Text(
                  label,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    // ✅ Mismo criterio para el texto
                    color: isSelected ? Colors.white : const Color(0xFF4A0060),
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                    height: 1.2,
                    shadows: const [
                      Shadow(
                        color: Colors.black26,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // =======================
        // OPCIÓN: CREAR PARTIDA
        // =======================
        _buildOptionCard(
          label: "CREAR\nPARTIDA",
          icon: Icons.add_circle_outline_rounded,
          key: "crear",
          onTap: () async {
            setState(() => gameSelcted = "crear");
            try {
              final Map<String, dynamic> partyData = await _partyService
                  .createParty(widget.user);
              if (!mounted) return;
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CreateParty(
                    pin: partyData['pin'].toString(),
                    user: widget.user,
                  ),
                ),
              );
            } catch (e) {
              if (!mounted) return;
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Error'),
                  content: Text('No se pudo crear la partida: $e'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('OK'),
                    ),
                  ],
                ),
              );
            }
          },
        ),

        // =======================
        // OPCIÓN: UNIRSE A PARTIDA
        // =======================
        _buildOptionCard(
          label: "UNIRSE A\nPARTIDA",
          icon: Icons.group_add_rounded,
          key: "unir",
          onTap: () {
            setState(() => gameSelcted = "unir");
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => JoinScreen(user: widget.user)),
            );
          },
        ),
      ],
    );
  }
}
