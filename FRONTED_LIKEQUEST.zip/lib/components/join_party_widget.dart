// Importa los widgets básicos de Flutter
import 'package:flutter/material.dart';

// Modelo User del jugador
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/screens/joined_party_screen.dart';

// Servicio para unirse a partidas
import 'package:like_quest_flutter/services/join_party_service.dart';

// Widget con estado para ingresar a una partida existente mediante PIN
class JoinPartyWidget extends StatefulWidget {
  final User user; // Usuario que intenta unirse
  const JoinPartyWidget({super.key, required this.user});

  @override
  State<JoinPartyWidget> createState() => _JoinPartyWidget();
}

class _JoinPartyWidget extends State<JoinPartyWidget> {
  // Servicio encargado de la lógica para unirse a partidas
  final JoinPartyService _joinPartyService = JoinPartyService();

  // Variable para almacenar el PIN que ingresa el usuario
  String pin = '';
  

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // =========================
        // BOTÓN VOLVER
        // =========================
        Positioned(
          top: 16,
          left: 16,
          child: IconButton(
            icon: const Icon(Icons.arrow_back),
            color: Colors.white, // Ajustar según fondo
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),

        // =========================
        // CUADRO CENTRAL PARA INGRESAR EL PIN
        // =========================
        Center(
          child: Container(
            height: 160,
            width: 260,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: const Color(0xFFFAF9FA),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // --- CAMPO DE TEXTO PARA PIN ---
                TextField(
                  onChanged: (value) {
                    // Actualiza la variable pin en tiempo real
                    setState(() {
                      pin = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'PIN de juego',
                    hintStyle: const TextStyle(color: Color(0xFFB0B0B0)),
                    border: OutlineInputBorder(
                      // Borde redondeado para el campo de texto
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      // Padding interno del campo de texto
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                  //Tipo de teclado
                  keyboardType: TextInputType.number,
                  maxLength: 10, // Limita a 10 caracteres
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 12),

                // --- BOTÓN INGRESAR ---
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      // Valida que haya un PIN ingresado
                      if (pin.isEmpty) {
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Por favor ingresa un PIN'),
                          ),
                        );
                        return;
                      }
                      try {
                        // Llamada al servicio para unirse a la partida
                        await _joinPartyService.joinParty(
                          pin: pin,
                          user: widget.user,
                        );
                        if (!context.mounted) return;

                        // Mensaje de éxito
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Partida encontrada con éxito'),
                          ),
                        );
                        
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) =>
                                JoinedParty(user: widget.user, pin: pin),
                          ),
                        );
                        // Aquí se podría navegar a la pantalla del juego
                      } catch (error) {
                        // Muestra el error si ocurre en la snackbar
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(error.toString())),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF333333),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Ingresar',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
