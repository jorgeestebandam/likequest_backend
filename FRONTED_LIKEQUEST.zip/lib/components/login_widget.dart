import 'package:flutter/material.dart';

class LoginWidget extends StatefulWidget {
  // 1. Agregamos esta línea para recibir la función del padre
  final Function(String) onUsernameChanged;

  const LoginWidget({super.key, required this.onUsernameChanged});

  @override
  State<LoginWidget> createState() => _LoginWidget();
}

class _LoginWidget extends State<LoginWidget> {
 

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 200,
        height: 75,
        child: TextField(
         // Se ejecuta cada vez que el usuario escribe
          onChanged: (value) { 
            // Se envía el texto actual al widget padre
            // mediante la función recibida por parámetro
            widget.onUsernameChanged(value);

          },
            // Decoración visual del TextField
          decoration: InputDecoration(
            filled: true,
            fillColor: const Color(0xA7FFFFFF),
             // Texto que aparece cuando el campo está vacío
            hintText: 'Usuario de tiktok',
            hintStyle: const TextStyle(color: Color(0xFF0E0D0D)),
              // Borde cuando el campo NO está enfocado
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
              // Borde cuando el campo SI está enfocado
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF333333), width: 2),
            ),
            // Espaciado interno del texto
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          keyboardType: TextInputType.text,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}