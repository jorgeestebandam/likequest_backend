import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/core/text.dart';

class MaximoJugadoresSlider extends StatefulWidget {
  final Function(double)? onValueChanged;
  const MaximoJugadoresSlider({super.key, this.onValueChanged});

  @override
  State<MaximoJugadoresSlider> createState() => _MaximoJugadoresSliderState();
}

class _MaximoJugadoresSliderState extends State<MaximoJugadoresSlider> {
  double maximoJugadores = 5;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.secondary,
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "MÁXIMO DE JUGADORES",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 8),
            Text(
              "${maximoJugadores.toStringAsFixed(0)} jugadores",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            Slider(
              value: maximoJugadores,
              onChanged: (newValue) {
                setState(() {
                  maximoJugadores = newValue;
                });
                widget.onValueChanged?.call(newValue);
              },
              min: 2,
              max: 10,
              divisions: 8,
              label: "${maximoJugadores.toStringAsFixed(0)}",
            ),
          ],
        ),
      ),
    );
  }
}