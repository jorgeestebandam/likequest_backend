import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/core/text.dart';


class NumeroRondasSlider extends StatefulWidget {
  final Function(double)? onValueChanged;
  const NumeroRondasSlider({super.key, this.onValueChanged});

  @override
  State<NumeroRondasSlider> createState() => _NumeroRondasSlider();
}

class _NumeroRondasSlider extends State<NumeroRondasSlider> {
  double numeroRondas = 10;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.secondary,
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "RONDAS",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 8),
           
            Text(
              "${numeroRondas.toStringAsFixed(0)} rondas",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            Slider(
              // Slider para seleccionar el número de rondas
              // empieza con el valor actual de numeroRondas en este caso 10
              value: numeroRondas,
              // Cuando el valor del slider cambia , la función onChanged se ejecuta
              // y actualiza el valor de la variable numeroRondas
              onChanged: (newValue) {
                setState(() {
                  numeroRondas = newValue;
                });
                widget.onValueChanged?.call(newValue);
              },
              // Rango del slider entre 5 y 25 con divisiones de 1
              // es decir al mover el slider se incrementa o decrementa en 1
              min: 5,
              max: 25,
              divisions: 20,
              // Etiqueta que muestra el valor actual del slider
              label: "${numeroRondas.toStringAsFixed(0)}",
            ),
          ],
        ),
      ),
    );
  }
}