import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/core/text.dart';

class unirseTardeSwitch extends StatefulWidget {
  final Function(bool)? onValueChanged;
  const unirseTardeSwitch({super.key, this.onValueChanged});

  @override
  State<unirseTardeSwitch> createState() => _unirseTardeSwitchState();
}

class _unirseTardeSwitchState extends State<unirseTardeSwitch> {
 
  bool  permitirUnirseTarde = false;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: AppColors.secondary,
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
             
              Text(
                "Permitir unirse más tarde",
                style: TextStyles.blanco,
              ),
              // Switch para permitir unirse tarde
              Transform.scale(
              // Ajusta el tamaño del switch
                scale: 0.9, 
                child: Switch(
                  // Valor actual del switch == false
                  value: permitirUnirseTarde,
                  // Cuando el switch cambia , se actualiza el valor de permitirUnirseTarde
                  onChanged: (value) {
                    setState(() {
                      permitirUnirseTarde = value;
                    });                    widget.onValueChanged?.call(value);                  },
                  activeColor: Colors.white,
                  // Colores cuando el switch está activo
                  activeTrackColor: AppColors.primary, 
                  // Color de la bola cuando está inactivo
                  inactiveThumbColor: Colors.white,
                  // Color de la pista cuando está inactivo
                  inactiveTrackColor: Colors.grey.shade400,
                  
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}