// Importa los widgets básicos de Flutter
import 'package:flutter/material.dart';

// Componentes reutilizables para configurar la partida
import 'package:like_quest_flutter/components/duracion_ronda_slider.dart';
import 'package:like_quest_flutter/components/maximos_jugadores_slider.dart';
import 'package:like_quest_flutter/components/permitir_unirse_tarde_switch.dart';
import 'package:like_quest_flutter/components/numero_rondas_slider.dart';

// Colores y estilos de texto centralizados
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/core/text.dart';

// Servicio encargado de enviar la configuración al backend
import 'package:like_quest_flutter/services/configuration_party_service.dart';

// Widget con estado para configurar los ajustes de una sala
class SeetingPartyWidget extends StatefulWidget {
  // PIN de la sala que se está configurando
  final String pin;

  const SeetingPartyWidget({
    super.key,
    required this.pin,
  });

  @override
  State<SeetingPartyWidget> createState() => _SeetingPartyWidget();
}

// Estado del widget de configuración
class _SeetingPartyWidget extends State<SeetingPartyWidget> {
  // Servicio para actualizar la configuración de la partida
  final ConfigurationPartyService _ConfigurationPartyService =
      ConfigurationPartyService();

  // Variables de estado para cada ajuste configurable
  double numeroRondas = 10;
  double duracionRonda = 30;
  double maximoJugadores = 5;
  bool permitirUnirseTarde = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),

      // Columna principal de la pantalla
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // =======================
          // CABECERA CON BOTÓN VOLVER
          // =======================
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Row(
              children: [
                // Botón personalizado de volver
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.secondary,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.arrow_back,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),

                // Título centrado
                Expanded(
                  child: Center(
                    child: Text(
                      "Ajustes de la Sala",
                      style: TextStyles.title,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),

                // Espacio para mantener el título centrado
                const SizedBox(width: 40),
              ],
            ),
          ),

          // =======================
          // CONTENIDO PRINCIPAL
          // =======================
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.backgroundWidget,
                borderRadius: BorderRadius.circular(12),
              ),

              // Scroll para pantallas pequeñas
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  vertical: 16,
                  horizontal: 8,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Slider para elegir el número de rondas
                    NumeroRondasSlider(
                      onValueChanged: (value) {
                        setState(() {
                          numeroRondas = value;
                        });
                      },
                    ),

                    const SizedBox(height: 8),

                    // Slider para definir la duración de cada ronda
                    RondasDuracionSlider(
                      onValueChanged: (value) {
                        setState(() {
                          duracionRonda = value;
                        });
                      },
                    ),

                    const SizedBox(height: 8),

                    // Slider para definir el máximo de jugadores
                    MaximoJugadoresSlider(
                      onValueChanged: (value) {
                        setState(() {
                          maximoJugadores = value;
                        });
                      },
                    ),

                    const SizedBox(height: 8),

                    // Switch para permitir o no que se unan tarde
                    unirseTardeSwitch(
                      onValueChanged: (value) {
                        setState(() {
                          permitirUnirseTarde = value;
                        });
                      },
                    ),

                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // =======================
          // BOTÓN GUARDAR CAMBIOS
          // =======================
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: () async {
                try {
                  // Se envía la configuración actual al backend, para que este la actualize
                  // en la partida correspondiente al PIN pasado
                  await _ConfigurationPartyService.updatePartyConfig(
                    pin: widget.pin,
                    numberRounds: numeroRondas.toInt(),
                    choiceTime: duracionRonda.toInt(),
                    maxUsers: maximoJugadores.toInt(),
                    joinLater: permitirUnirseTarde,
                  );

                  // Mensaje de éxito
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Configuración guardada"),
                    ),
                  );
                } catch (e) {
                  // Mensaje de error
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Error: ${e.toString()}"),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.backgroundAppBar,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Guardar Cambios',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
