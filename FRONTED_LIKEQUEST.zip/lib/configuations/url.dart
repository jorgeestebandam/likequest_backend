
class url {
  // Ruta donde apunta el backend
  static const String baseNgrock = 'http://localhost:8080/api';
}
