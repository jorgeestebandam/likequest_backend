import 'package:flutter/material.dart';
import '../models/round.dart';
import '../models/player_score.dart';
import 'package:like_quest_flutter/models/GameInitModel.dart'; // tu modelo existente

/// Estados posibles de la partida
enum GamePhase {
  video,      // Reproduciendo vídeo
  answering,  // Pantalla de respuesta
  roundResult,// Resultado de la ronda
  finished,   // Partida terminada
}

/// Controlador principal de la partida — usa ChangeNotifier para notificar a la UI
class GameLoopController extends ChangeNotifier {
  // ── Datos de la partida ──────────────────────────────────────────────────
  final List<String> players;
  final List<Round> rounds;
  final int choiceTime; // segundos para responder

  // ── Estado actual ────────────────────────────────────────────────────────
  int _currentRoundIndex = 0;
  GamePhase _phase = GamePhase.video;
  String? _selectedAnswer;       // Respuesta que eligió el jugador local
  bool? _lastAnswerCorrect;      // Si la última respuesta fue correcta
  int _lastPointsEarned = 0;     // Puntos ganados en la última ronda
  int _responseTimeMs = 0;       // Tiempo que tardó en responder

  // ── Puntuaciones ────────────────────────────────────────────────────────
  late Map<String, PlayerScore> _scores;

  // ── Getters ──────────────────────────────────────────────────────────────
  int get currentRoundIndex => _currentRoundIndex;
  GamePhase get phase => _phase;
  String? get selectedAnswer => _selectedAnswer;
  bool? get lastAnswerCorrect => _lastAnswerCorrect;
  int get lastPointsEarned => _lastPointsEarned;
  int get responseTimeMs => _responseTimeMs;
  Round get currentRound => rounds[_currentRoundIndex];
  bool get isLastRound => _currentRoundIndex >= rounds.length - 1;
  List<PlayerScore> get sortedScores {
    final list = _scores.values.toList();
    list.sort((a, b) => b.totalPoints.compareTo(a.totalPoints));
    return list;
  }

  GameLoopController({
    required this.players,
    required this.rounds,
    required this.choiceTime,
  }) {
    // Inicializa puntuación a 0 para cada jugador
    _scores = {
      for (final p in players) p: PlayerScore(username: p)
    };
  }

  /// Factory desde el modelo del backend
  factory GameLoopController.fromGameInit(GameInitModel gameInit) {
    return GameLoopController(
      players: gameInit.players,
      rounds: Round.fromQuestionsMap(gameInit.questions),
      choiceTime: gameInit.choiceTime,
    );
  }

  // ── Flujo del juego ──────────────────────────────────────────────────────

  /// Llamar cuando el vídeo termina → pasa a pantalla de respuesta
  void onVideoFinished() {
    _phase = GamePhase.answering;
    _selectedAnswer = null;
    _lastAnswerCorrect = null;
    notifyListeners();
  }

  /// Llamar cuando el jugador selecciona una respuesta
  void submitAnswer(String answer, int responseTimeMs) {
  if (_selectedAnswer != null) return;

  _selectedAnswer = answer;
  _responseTimeMs = responseTimeMs;
  _lastAnswerCorrect = answer == currentRound.correctAnswer;

  if (_lastAnswerCorrect!) {
    // Normaliza el tiempo respecto al choiceTime total
    final maxMs = choiceTime * 1000;
    final ratio = (responseTimeMs / maxMs).clamp(0.0, 1.0); // 0 = rapidísimo, 1 = tardísimo
    _lastPointsEarned = (1000 * (1 - ratio)).clamp(100, 1000).toInt();
  } else {
    _lastPointsEarned = 0;
  }

  _phase = GamePhase.roundResult;
  notifyListeners();
}

  /// Llamar cuando el tiempo se acaba sin responder
  void onTimeOut() {
    if (_selectedAnswer != null) return;
    submitAnswer('', choiceTime * 1000); // respuesta vacía = fallo
  }

  /// Registra la puntuación de un jugador específico (para multijugador)
  void registerPlayerAnswer(String username, String answer, int responseTimeMs) {
  _scores[username]?.addAnswer(
    correct: answer == currentRound.correctAnswer,
    responseTimeMs: responseTimeMs,
    choiceTimeSeconds: choiceTime, // ← añade esto
  );
}

  /// Avanza a la siguiente ronda o termina la partida
  void nextRound() {
    if (isLastRound) {
      _phase = GamePhase.finished;
    } else {
      _currentRoundIndex++;
      _phase = GamePhase.video;
      _selectedAnswer = null;
      _lastAnswerCorrect = null;
    }
    notifyListeners();
  }

  /// Reinicia la partida desde el principio
  void restart() {
    _currentRoundIndex = 0;
    _phase = GamePhase.video;
    _selectedAnswer = null;
    _lastAnswerCorrect = null;
    _scores = {
      for (final p in players) p: PlayerScore(username: p)
    };
    notifyListeners();
  }

  PlayerScore? getScore(String username) => _scores[username];
}