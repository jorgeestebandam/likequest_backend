import 'package:flutter/material.dart';

class AppColors {
  // ── Fondo ──────────────────────────────────────────────────────────────────
  static const Color backgroundApp = Color(0x60B712D8);
  static const Color backgroundWidget = Color(0xFFB554F1);
  static const Color backgroundAppBar = Color(0xF579014D);

  // ── Gradiente de fondo principal ───────────────────────────────────────────
  static const List<Color> backgroundGradient = [
    Color(0xFF12042A),
    Color(0xFF1E0A45),
    Color(0xFF2D1260),
  ];

  // ── Widgets ────────────────────────────────────────────────────────────────
  static const Color primary = Color(0xFF7306AA);
  static const Color secondary = Color(0xFF6A0DAD);
  static const Color accent = Color(0xFFE40D8E);

  // ── Tarjetas ───────────────────────────────────────────────────────────────
  static const Color cardBackground = Color(0xFF2D1260);
  static const Color cardBorder = Color(0xFF5B2DB0);

  // ── Textos ─────────────────────────────────────────────────────────────────
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFCBB8F5);
  static const Color textMuted = Color(0xFF8A6FC4);
  static const Color backgroundColorTexts = Color(0xF579014D);

  // ── Acentos semánticos (usados en métricas del perfil) ────────────────────
  static const Color accentGold = Color(0xFFFFD700);
  static const Color accentGreen = Color(0xFF34D399);
  static const Color accentBlue = Color(0xFF60A5FA);
  static const Color accentIndigo = Color(0xFF818CF8);
  static const Color accentOrange = Color(0xFFF97316);
  static const Color accentRed = Color(0xFFF87171);
  static const Color purpleLight = Color(0xFFB48EF7);
}