import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';

class TextStyles {
  static const TextStyle normal = TextStyle(
    color: AppColors.backgroundColorTexts,
    fontSize: 15,
  );
  static const TextStyle blanco = TextStyle(
    color: Color(0xF5F8F6F7),
    fontSize: 15,
  );
  static const TextStyle title = TextStyle(
    color: AppColors.textPrimary,
    fontSize: 22,
    fontWeight: FontWeight.bold,
  );
}
