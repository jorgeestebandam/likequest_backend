import 'package:flutter/material.dart';

class AuthDialogs {
  static void mostrarErrorPrivacidad(BuildContext context) {
    _mostrarDialogoError(
      context,
      'Perfil Privado',
      'El perfil de este usuario es privado.',
    );
  }
  static void mostrarErrorVideosPrivados(BuildContext context) {
    _mostrarDialogoError(
      context,
      'Videos Privados',
      'Los videos de este usuario son privados.',
    );
  }
  static void mostrarErrorUsuarioNoEncontrado(BuildContext context, String? username) {
    _mostrarDialogoError(
      context,
      'Usuario No Encontrado',
      'El usuario no fue encontrado.',
    );
  }
  static void mostrarErrorConexion(BuildContext context) {
    _mostrarDialogoError(
      context,
      'Error de Conexión',
      'Ocurrió un error al conectar. Intenta de nuevo más tarde.',
    );
  }
  static void _mostrarDialogoError(
    BuildContext context,
    String titulo,
    String mensaje,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(titulo),
        content: Text(mensaje),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}