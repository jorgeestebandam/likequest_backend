import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/screens/login_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: AppColors.backgroundApp,
        appBar: AppBar(
          backgroundColor: AppColors.backgroundAppBar,
          foregroundColor: AppColors.textPrimary,
          title: Text("LikeQuest"),
        ),
        body: Login(),
      ),
    );
  }
}
