class GameInitModel {
  final List<String> players;
  final Map<String, String> questions;
  final int totalRounds;
  final int choiceTime;

  GameInitModel({
    required this.players,
    required this.questions,
    required this.totalRounds,
    required this.choiceTime,
  });

  factory GameInitModel.fromJson(Map<String, dynamic> json) {
    return GameInitModel(
      players: List<String>.from(json['players']),
      questions: Map<String, String>.from(json['questions']),
      totalRounds: json['totalRounds'],
      choiceTime: json['choiceTime'],
    );
  }
}
