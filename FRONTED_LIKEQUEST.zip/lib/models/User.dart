class User {
  final String username;
  final List<String> urlVideos;

  User({
    required this.username,
    required this.urlVideos,
  });

  //Tranformar JSON a User
  factory User.fromJson(Map<String, dynamic> json) {
    var videosFromJson = json['urlVideosLiked'] as List? ?? [];

    List<String> videosList =
        videosFromJson.map((v) => v.toString()).toList();

    return User(
      username: json['username'] ?? '',
      urlVideos: videosList,
    );
  }

  get name => null;

  // Tranformar User a JSON 
  Map<String, dynamic> toJson() {
    
    return {
      'username': username,
      'urlVideosLiked': urlVideos,
    };
  }
}