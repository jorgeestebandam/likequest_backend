class GameScore {
  final int id;
  final String pin;
  final String username;
  final int points;
  final int correctAnswers;
  final int totalRounds;
  final double avgResponseTimeMs;
  final DateTime createdAt;

  GameScore({
    required this.id,
    required this.pin,
    required this.username,
    required this.points,
    required this.correctAnswers,
    required this.totalRounds,
    required this.avgResponseTimeMs,
    required this.createdAt,
  });

  factory GameScore.fromJson(Map<String, dynamic> json) {
    return GameScore(
      id: json['id'] ?? 0,
      pin: json['pin'] ?? '',
      username: json['username'] ?? '',
      points: json['points'] ?? 0,
      correctAnswers: json['correctAnswers'] ?? 0,
      totalRounds: json['totalRounds'] ?? 0,
      avgResponseTimeMs:
          (json['avgResponseTimeMs'] ?? 0).toDouble(),
      createdAt: DateTime.parse(json['createdAt']),
    );
  }
}