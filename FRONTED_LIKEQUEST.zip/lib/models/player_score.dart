/// Modelo que representa la puntuación de un jugador durante la partida
class PlayerScore {
  final String username;
  int totalPoints;
  int correctAnswers;
  List<int> responseTimes; // tiempos de respuesta en ms por ronda

  PlayerScore({
    required this.username,
    this.totalPoints = 0,
    this.correctAnswers = 0,
    List<int>? responseTimes,
  }) : responseTimes = responseTimes ?? [];

  /// Añade puntos por una respuesta correcta según velocidad
  /// Fórmula: puntos = acierto ? max(100, 1000 - tiempoMs) : 0
  void addAnswer({required bool correct, required int responseTimeMs, required int choiceTimeSeconds}) {
  responseTimes.add(responseTimeMs);
  if (correct) {
    correctAnswers++;
    final maxMs = choiceTimeSeconds * 1000;
    final ratio = (responseTimeMs / maxMs).clamp(0.0, 1.0);
    final points = (1000 * (1 - ratio)).clamp(100, 1000).toInt();
    totalPoints += points;
  }
}

  /// Tiempo medio de respuesta en ms
  double get averageResponseTime {
    if (responseTimes.isEmpty) return 0;
    return responseTimes.reduce((a, b) => a + b) / responseTimes.length;
  }
}