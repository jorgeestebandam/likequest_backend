/// Modelo que representa una ronda del juego
class Round {
  final int roundNumber;       // Número de ronda (1, 2, 3...)
  final String correctAnswer;  // Respuesta correcta (username del jugador)
  final String videoUrl;       // URL del vídeo a reproducir

  Round({
    required this.roundNumber,
    required this.correctAnswer,
    required this.videoUrl,
  });

  /// Parsea las questions del backend con formato: "ronda_X_username" -> "url"
  static List<Round> fromQuestionsMap(Map<String, String> questions) {
    final List<Round> rounds = [];

    questions.forEach((key, videoUrl) {
      // key = "ronda_1_jorge.esteban.dam"
      final parts = key.split('_');
      // parts[0] = "ronda", parts[1] = número, parts[2..] = username (puede tener puntos)
      if (parts.length >= 3) {
        final roundNumber = int.tryParse(parts[1]) ?? 0;
        // El username empieza en parts[2] (puede tener guiones bajos en el nombre)
        final correctAnswer = parts.sublist(2).join('_');
        rounds.add(Round(
          roundNumber: roundNumber,
          correctAnswer: correctAnswer,
          videoUrl: videoUrl,
        ));
      }
    });

    // Ordenar por número de ronda
    rounds.sort((a, b) => a.roundNumber.compareTo(b.roundNumber));
    return rounds;
  }
}