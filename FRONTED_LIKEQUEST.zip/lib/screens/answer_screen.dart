import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/game_loop_controller.dart';

/// Pantalla de respuesta estilo Kahoot
class AnswerScreen extends StatefulWidget {
  final String currentUsername; // usuario local que está jugando

  const AnswerScreen({super.key, required this.currentUsername});

  @override
  State<AnswerScreen> createState() => _AnswerScreenState();
}

class _AnswerScreenState extends State<AnswerScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _timerController;
  late DateTime _startTime;
  bool _answered = false;

  // Colores para los botones de respuesta (estilo Kahoot)
  static const List<Color> _buttonColors = [
    Color(0xFFE53935), // rojo
    Color(0xFF1E88E5), // azul
    Color(0xFF43A047), // verde
    Color(0xFFFB8C00), // naranja
    Color(0xFF8E24AA), // morado
    Color(0xFF00ACC1), // cyan
    Color(0xFFD81B60), // rosa
    Color(0xFF6D4C41), // marrón
  ];

  @override
  void initState() {
    super.initState();
    _startTime = DateTime.now();

    final choiceTime = context.read<GameLoopController>().choiceTime;
    _timerController = AnimationController(
      vsync: this,
      duration: Duration(seconds: choiceTime),
    )..forward();

    _timerController.addStatusListener((status) {
      if (status == AnimationStatus.completed && !_answered) {
        context.read<GameLoopController>().onTimeOut();
      }
    });
  }

  @override
  void dispose() {
    _timerController.dispose();
    super.dispose();
  }

  void _onAnswer(String answer) {
    if (_answered) return;
    _answered = true;
    _timerController.stop();

    final responseTimeMs =
        DateTime.now().difference(_startTime).inMilliseconds;

    final ctrl = context.read<GameLoopController>();
    ctrl.submitAnswer(answer, responseTimeMs);
    // También registra para el jugador local en el mapa de scores
    ctrl.registerPlayerAnswer(widget.currentUsername, answer, responseTimeMs);
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<GameLoopController>();
    final players = controller.players;
    final choiceTime = controller.choiceTime;

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: SafeArea(
        child: Column(
          children: [
            // ── Temporizador ─────────────────────────────────────────
            AnimatedBuilder(
              animation: _timerController,
              builder: (_, __) {
                final remaining =
                    ((1 - _timerController.value) * choiceTime).ceil();
                return Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  color: const Color(0xFF1A1A2E),
                  child: Column(
                    children: [
                      Text(
                        '$remaining',
                        style: TextStyle(
                          color: remaining <= 5
                              ? const Color(0xFFFF6584)
                              : Colors.white,
                          fontSize: 48,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: LinearProgressIndicator(
                          value: 1 - _timerController.value,
                          backgroundColor: Colors.white12,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            remaining <= 5
                                ? const Color(0xFFFF6584)
                                : const Color(0xFF6C63FF),
                          ),
                          minHeight: 6,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),

            // ── Pregunta ─────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
              child: Text(
                '¿Quién a dado like a este vídeo?',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),

            // ── Botones de jugadores ──────────────────────────────────
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 2.5,
                  ),
                  itemCount: players.length,
                  itemBuilder: (context, index) {
                    final player = players[index];
                    final color = _buttonColors[index % _buttonColors.length];

                    return _AnswerButton(
                      label: player,
                      color: color,
                      disabled: _answered,
                      onTap: () => _onAnswer(player),
                    );
                  },
                ),
              ),
            ),

            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class _AnswerButton extends StatefulWidget {
  final String label;
  final Color color;
  final bool disabled;
  final VoidCallback onTap;

  const _AnswerButton({
    required this.label,
    required this.color,
    required this.disabled,
    required this.onTap,
  });

  @override
  State<_AnswerButton> createState() => _AnswerButtonState();
}

class _AnswerButtonState extends State<_AnswerButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: GestureDetector(
        onTapDown: (_) => _scaleController.forward(),
        onTapUp: (_) {
          _scaleController.reverse();
          if (!widget.disabled) widget.onTap();
        },
        onTapCancel: () => _scaleController.reverse(),
        child: AnimatedOpacity(
          opacity: widget.disabled ? 0.5 : 1.0,
          duration: const Duration(milliseconds: 200),
          child: Container(
            decoration: BoxDecoration(
              color: widget.color,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: widget.color.withOpacity(0.4),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Center(
              child: Text(
                widget.label,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
      ),
    );
  }
}