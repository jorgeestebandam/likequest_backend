import 'package:flutter/material.dart';
import 'package:like_quest_flutter/components/codigo_sala_widget.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/services/party_service.dart';

class CreateParty extends StatefulWidget {
  final String pin;
  final User user;
  const CreateParty({super.key, required this.pin, required this.user});

  @override
  State<CreateParty> createState() => _CreateParty();
}

class _CreateParty extends State<CreateParty> {
  // Instancia del servicio de partidas - backend
  PartyService _partyService = PartyService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundApp,
      appBar: AppBar(
        backgroundColor: AppColors.backgroundAppBar,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        // Botón de retroceso personalizado , si se pulsa vuelve a la pantalla anterior y
        // elimina la partida creada
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textPrimary),
          onPressed: () async {
            try {
              // Llamada al servicio para eliminar la partida - backend
              await _partyService.deleteParty(widget.pin);

              // muestra un mensaje de confirmación de que la partida ha sido eliminada
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Partida eliminada")),
              );

              // Cierra la pantalla
              Navigator.of(context).pop();
            } catch (e) {
              // Si hay un error, muestra un mensaje de error en el Snackbar
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Error al eliminar la partida: $e")),
              );
            }
          },
          splashRadius: 24, // opcional
        ),
        title: const Text("Crear partida"),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Row(
              children: [
                // Widget que muestra el código de la sala , le pasamos el pin y el usuario creador
                Expanded(
                  child: CodigoSalaWidget(pin: widget.pin, user: widget.user),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
