import 'package:flutter/material.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:provider/provider.dart';
import '../controllers/game_loop_controller.dart';
import 'package:like_quest_flutter/models/GameInitModel.dart';
import 'video_round_screen.dart';
import 'answer_screen.dart';
import 'round_result_screen.dart';
import 'leaderboard_screen.dart';

class GameScreen extends StatelessWidget {
  final User user;
  final String pin;
  final String currentUsername;
  final String creador;
  final GameInitModel gameInit;

  const GameScreen({
    super.key,
    required this.user,
    required this.pin,
    required this.currentUsername,
    required this.creador,
    required this.gameInit,
  });

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => GameLoopController.fromGameInit(gameInit),
      child: _GameScreenBody(
        pin: pin,
        user: user,
        currentUsername: currentUsername,
        onExit: () => Navigator.of(context).popUntil((r) => r.isFirst),
      ),
    );
  }
}

class _GameScreenBody extends StatelessWidget {
  final String pin;
  final User user;
  final String currentUsername;
  final VoidCallback onExit;

  const _GameScreenBody({
    required this.pin,
    required this.user,
    required this.currentUsername,
    required this.onExit,
  });

  @override
  Widget build(BuildContext context) {
    final phase = context.watch<GameLoopController>().phase;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 400),
      transitionBuilder: (child, animation) =>
          FadeTransition(opacity: animation, child: child),
      child: switch (phase) {
        GamePhase.video => const VideoRoundScreen(key: ValueKey('video')),
        GamePhase.answering => AnswerScreen(
            key: const ValueKey('answer'),
            currentUsername: currentUsername,
          ),
        GamePhase.roundResult => RoundResultScreen(  // ← sin const
            key: const ValueKey('result'),
            pin: pin,
            currentUsername: currentUsername,
          ),
        GamePhase.finished => LeaderboardScreen(
            key: const ValueKey('leaderboard'),
            pin: pin,
            user : user,
            currentUsername: currentUsername,
            onExit: onExit,
          ),
      },
    );
  }
}