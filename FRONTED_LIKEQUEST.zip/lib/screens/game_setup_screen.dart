import 'package:flutter/material.dart';
import 'package:like_quest_flutter/models/GameInitModel.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/screens/game_screen.dart';
import 'package:like_quest_flutter/services/game_setup_service.dart';

class GameSetupScreen extends StatefulWidget {
  final String pin;
  final User user;
  final String creador;

  const GameSetupScreen({super.key, required this.pin, required this.user, required this.creador});

  @override
  State<GameSetupScreen> createState() => _GameSetupScreenState();
}

class _GameSetupScreenState extends State<GameSetupScreen>
    with SingleTickerProviderStateMixin {
  final GameSetUpService _gameSetUpService = GameSetUpService();
  GameInitModel? gameInit;

  late AnimationController _animationController;
  bool _backendListo = false;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 50),
    );

    _animationController.forward();
    _animationController.addStatusListener(_onAnimacionTerminada);

    if (widget.user.username == widget.creador) {
      cargarPartida();
    } else {
      esperarPartida();
    }
  }

  void _onAnimacionTerminada(AnimationStatus status) {
    if (status == AnimationStatus.completed && _backendListo) {
      _navegarSiguientePantalla();
    }
  }

  Future<void> cargarPartida() async {
    final result = await _gameSetUpService.cargarPartida(widget.pin)
        .timeout(const Duration(seconds: 100), onTimeout: () => null);

    setState(() {
      gameInit = result;
      _backendListo = result != null;
    });

    if (result == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error cargando la partida, intenta de nuevo')),
        );
        Navigator.pop(context);
      }
      return;
    }

    if (_animationController.status == AnimationStatus.completed) {
      _navegarSiguientePantalla();
    }
  }

  Future<void> esperarPartida() async {
    GameInitModel? result;

    while (result == null) {
      await Future.delayed(const Duration(seconds: 2));
      result = await _gameSetUpService.obtenerPartidaLista(widget.pin);
    }

    setState(() {
      gameInit = result;
      _backendListo = true;
    });

    if (_animationController.status == AnimationStatus.completed) {
      _navegarSiguientePantalla();
    }
  }

  void _navegarSiguientePantalla() {
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => GameScreen(
          pin: widget.pin,
          currentUsername: widget.user.username,  // usuario local
          creador: widget.creador,
          gameInit: gameInit!,
          user: widget.user,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.removeStatusListener(_onAnimacionTerminada);
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/fondo2.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _animationController,
                builder: (context, child) {
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 220,
                        height: 220,
                        child: CircularProgressIndicator(
                          value: _animationController.value,
                          strokeWidth: 5,
                          backgroundColor: Colors.white24,
                          valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                        ),
                      ),
                      ClipOval(
                        child: Image.asset(
                          'assets/images/LogoAppLikeQuest.png',
                          height: 220,
                          width: 220,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 20),
              Text(
                widget.user.username == widget.creador
                    ? 'Preparando la partida...'
                    : 'Esperando al creador...',
                style: const TextStyle(color: Colors.white, fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}