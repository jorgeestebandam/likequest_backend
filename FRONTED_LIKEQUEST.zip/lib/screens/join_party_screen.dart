import 'package:flutter/material.dart';
import 'package:like_quest_flutter/components/join_party_widget.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/models/User.dart';

class JoinScreen extends StatelessWidget {
  final User user;
  const JoinScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundApp,
      body: SafeArea(
        child: Center(
          child: JoinPartyWidget(user: user),
        ),
      ),
    );
  }
}
