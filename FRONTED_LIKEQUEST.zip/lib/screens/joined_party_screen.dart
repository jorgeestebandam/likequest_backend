import 'package:flutter/material.dart';
import 'package:like_quest_flutter/components/codigo_sala_widget.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/services/join_party_service.dart';

class JoinedParty extends StatefulWidget {
  final User user;
  final String pin;

  const JoinedParty({super.key, required this.user, required this.pin});

  @override
  State<JoinedParty> createState() => _JoinedPartyState();
}

class _JoinedPartyState extends State<JoinedParty> {
  final JoinPartyService joinPartyService = JoinPartyService();

  Future<void> _leaveParty() async {
    await joinPartyService.leaveParty(pin: widget.pin, user: widget.user);

    if (!mounted) return; // seguridad

    // Mostrar mensaje de que abandonó la partida
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("Has abandonado la partida")));

    // Volver a la pantalla anterior después de mostrar el SnackBar
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) Navigator.of(context).pop();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundApp,
      appBar: AppBar(
        backgroundColor: AppColors.backgroundApp,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _leaveParty,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: CodigoSalaWidget(pin: widget.pin, user: widget.user),
        ),
      ),
    );
  }
}
