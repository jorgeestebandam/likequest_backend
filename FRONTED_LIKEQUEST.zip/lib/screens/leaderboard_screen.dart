import 'package:flutter/material.dart';
import 'package:like_quest_flutter/screens/select_game_screen.dart';
import 'package:provider/provider.dart';
import 'package:like_quest_flutter/models/User.dart'; // ajusta la ruta
import '../controllers/game_loop_controller.dart';
import '../services/scores_service.dart';

// ✅ Enum para los tres estados de carga
enum _LoadingPhase { uploading, waitingPlayers, done }

class LeaderboardScreen extends StatefulWidget {
  final String pin;
  final String currentUsername;
  final User user;
  final VoidCallback onExit;

  const LeaderboardScreen({
    super.key,
    required this.pin,
    required this.currentUsername,
    required this.user,
    required this.onExit,
  });

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  final ScoresService _scoresService = ScoresService(
    baseUrl: 'http://localhost:8080',
  );

  List<RemotePlayerScore> _scores = [];
  // ✅ Reemplaza bool _loading
  _LoadingPhase _phase = _LoadingPhase.uploading;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _uploadAndLoad();
  }

  Future<void> _uploadAndLoad() async {
    final ctrl = context.read<GameLoopController>();
    final localScore = ctrl.getScore(widget.currentUsername);

    // ── 1. Subir puntuación local ─────────────────────────────────
    if (localScore != null) {
      await _scoresService.saveScore(
        pin: widget.pin,
        username: widget.currentUsername,
        points: localScore.totalPoints,
        correctAnswers: localScore.correctAnswers,
        totalRounds: ctrl.rounds.length,
        avgResponseTimeMs: localScore.averageResponseTime,
      );
    }

    // ── 2. Esperar a que todos suban su puntuación ────────────────
    if (mounted) setState(() => _phase = _LoadingPhase.waitingPlayers);

    List<RemotePlayerScore> scores = [];
    int attempts = 0;
    while (scores.length < ctrl.players.length && attempts < 20) {
      await Future.delayed(const Duration(seconds: 2));
      scores = await _scoresService.getScores(widget.pin);
      // ✅ Actualizamos _scores en cada polling para mostrar el contador
      if (mounted) setState(() => _scores = scores);
      attempts++;
    }

    // ── 3. Todos listos → mostrar podio ───────────────────────────
    if (mounted) {
      setState(() {
        _scores = scores..sort((a, b) => b.points.compareTo(a.points));
        _phase = _LoadingPhase.done;
      });
      _animController.forward();
    }
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: SafeArea(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Text(
                '🏆 RESULTADO FINAL',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
              ),
            ),

            // ✅ Pantalla de espera con dos mensajes distintos
            if (_phase != _LoadingPhase.done)
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const CircularProgressIndicator(color: Color(0xFF6C63FF)),
                      const SizedBox(height: 24),
                      Text(
                        _phase == _LoadingPhase.uploading
                            ? 'Enviando tu puntuación...'
                            : 'Esperando a los demás jugadores...',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                        ),
                      ),
                      if (_phase == _LoadingPhase.waitingPlayers) ...[
                        const SizedBox(height: 12),
                        // ✅ Contador de jugadores listos
                        Consumer<GameLoopController>(
                          builder: (_, ctrl, __) => Text(
                            '${_scores.length} / ${ctrl.players.length} listos',
                            style: const TextStyle(
                              color: Color(0xFF6C63FF),
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              )
            else ...[
              // ── Podio ─────────────────────────────────────────────
              if (_scores.isNotEmpty)
                SizedBox(height: 210, child: _buildPodium()),

              const SizedBox(height: 16),

              // ── Clasificación completa ─────────────────────────────
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _scores.length,
                  itemBuilder: (context, index) {
                    final score = _scores[index];
                    final isMe = score.username == widget.currentUsername;

                    return AnimatedBuilder(
                      animation: _animController,
                      builder: (_, child) {
                        final delay = (index * 0.1).clamp(0.0, 0.9);
                        final animValue =
                            ((_animController.value - delay) / (1 - delay))
                                .clamp(0.0, 1.0);
                        return Opacity(
                          opacity: animValue,
                          child: Transform.translate(
                            offset: Offset(0, 30 * (1 - animValue)),
                            child: child,
                          ),
                        );
                      },
                      child: _ScoreRow(
                        score: score,
                        position: index + 1,
                        isMe: isMe,
                      ),
                    );
                  },
                ),
              ),
            ],

            // ── Botón Salir ────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(20),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(
                        builder: (_) => SelectGameScreen(user: widget.user),
                      ),
                      (route) => false,
                    );
                  },
                  icon: const Icon(Icons.exit_to_app),
                  label: const Text('Salir'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6C63FF),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPodium() {
    final podiumOrder = <RemotePlayerScore?>[];
    podiumOrder.add(_scores.length > 1 ? _scores[1] : null);
    podiumOrder.add(_scores.isNotEmpty ? _scores[0] : null);
    podiumOrder.add(_scores.length > 2 ? _scores[2] : null);

    final heights = [80.0, 110.0, 60.0];
    final colors = [
      const Color(0xFFC0C0C0),
      const Color(0xFFFFD700),
      const Color(0xFFCD7F32),
    ];
    final labels = ['2º', '1º', '3º'];

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (i) {
        final player = podiumOrder[i];

        if (player == null) {
          return SizedBox(width: 106, height: heights[i]);
        }

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: SizedBox(
            width: 90,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  player.username,
                  style: const TextStyle(color: Colors.white, fontSize: 11),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Text(
                  '${player.points}pts',
                  style: TextStyle(
                    color: colors[i],
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Container(
                  width: 90,
                  height: heights[i],
                  decoration: BoxDecoration(
                    color: colors[i].withOpacity(0.2),
                    border: Border.all(color: colors[i], width: 2),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(8),
                      topRight: Radius.circular(8),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      labels[i],
                      style: TextStyle(
                        color: colors[i],
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _ScoreRow extends StatelessWidget {
  final RemotePlayerScore score;
  final int position;
  final bool isMe;

  const _ScoreRow({
    required this.score,
    required this.position,
    required this.isMe,
  });

  @override
  Widget build(BuildContext context) {
    final medals = ['🥇', '🥈', '🥉'];
    final medal = position <= 3 ? medals[position - 1] : '$position.';

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: isMe
            ? const Color(0xFF6C63FF).withOpacity(0.15)
            : Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isMe
              ? const Color(0xFF6C63FF).withOpacity(0.5)
              : Colors.transparent,
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 36,
            child: Text(medal, style: const TextStyle(fontSize: 20)),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      score.username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (isMe) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF6C63FF),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          'TÚ',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                Text(
                  '${score.correctAnswers}/${score.totalRounds} aciertos · '
                  '${score.avgResponseTimeMs.toStringAsFixed(0)}ms promedio',
                  style: const TextStyle(color: Colors.white38, fontSize: 12),
                ),
              ],
            ),
          ),
          Text(
            '${score.points} pts',
            style: const TextStyle(
              color: Color(0xFF6C63FF),
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
}
