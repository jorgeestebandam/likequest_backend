import 'package:flutter/material.dart';
import 'package:like_quest_flutter/components/login_widget.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/screens/conditions_screen.dart';
import 'package:like_quest_flutter/screens/select_game_screen.dart';
import 'package:like_quest_flutter/services/auth_service.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String username = "";
  // Instancia del servicio de autenticación
  final AuthService _authService = AuthService();

  // --- MÉTODO PRINCIPAL DE LOGIN ---
  // Se ejecuta cuando el usuario pulsa el botón "Continuar"
  Future<void> _manejarLogin() async {
    // Validación: si el campo está vacío, se muestra una alerta
    if (username.trim().isEmpty) {
      _mostrarAlerta('Atención', 'Escribe un usuario');
      return;
    }

    // Mostrar un diálogo de carga mientras se consulta el servidor
    if (mounted) {
      showDialog(
        context: context,
        barrierDismissible: false, // No permite cerrar tocando fuera
        builder: (_) => const AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),  // Spinner de carga
              SizedBox(height: 16),
              Text('Cargando datos...'),
            ],
          ),
        ),
      );
    }
    try {
      // Llamada al servicio que verifica el username en el backend
      final response = await _authService.verificarUsername(username);
      // Verifica que el widget sigue montado antes de usar el context
      if (!mounted) return;
      Navigator.pop(context); // cerrar la barra de carga

      // Si el login es correcto y existe el usuario, navegamos a la siguiente pantalla
      if (response.success && response.user != null) {
        // Navegamos a SelectGameScreen pasando el User
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SelectGameScreen(user: response.user!),
          ),
        );
      } else {
        // Mostrar errores usando el propio AuthService
        _authService.manejarErrorLogin(context, response);
      }
       // En caso de error de conexión con el servidor muestro esta alerta
    } catch (e) {
      if (mounted) Navigator.pop(context); // cerrar loading si hay error
      _mostrarAlerta('Error', 'No se pudo conectar al servidor.');
    }
  }

   // Muestra un AlertDialog reutilizable con título y mensaje 
  void _mostrarAlerta(String titulo, String mensaje) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(titulo),
        content: Text(mensaje),
        actions: [
          // botón para cerrar el diálogo
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
           // Botón que lleva a la pantalla de términos y condiciones
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ConditionsScreen()),
              );
            },
            child: const Text('Términos del juego'),
          ),
        ],
      ),
    );
  }

  // --- BUILD DEL LOGIN ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/fondo2.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "Bienvenido a LikeQuest",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Image.asset('assets/images/logoTiktok.png', height: 100),
                const SizedBox(height: 32),
                  // Widget personalizado para introducir el username
                LoginWidget(
                  onUsernameChanged: (val) => setState(() => username = val),
                ),
                const SizedBox(height: 24),
                 // Botón que inicia de backend con el login
                ElevatedButton(
                  onPressed: _manejarLogin,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.backgroundAppBar,
                  ),
                  child: const Text(
                    'Continuar',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}