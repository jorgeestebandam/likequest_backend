import 'dart:math';
import 'package:flutter/material.dart';
import 'package:like_quest_flutter/core/color.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/models/game_score.dart';
import 'package:like_quest_flutter/services/profile_service.dart';
import 'package:like_quest_flutter/components/profile_components.dart';

class ProfileScreen extends StatefulWidget {
  final User user;

  const ProfileScreen({super.key, required this.user});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  final ProfileService _profileService = ProfileService();
  late Future<List<GameScore>> futureScores;
  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    futureScores = _profileService.getUserScores(widget.user.username);
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  ({String label, Color color, IconData icon}) _nivel(double accuracy) {
    if (accuracy >= 90) {
      return (
        label: 'Maestro',
        color: AppColors.accentGold,
        icon: Icons.workspace_premium,
      );
    } else if (accuracy >= 75) {
      return (
        label: 'Experto',
        color: AppColors.accentGreen,
        icon: Icons.military_tech,
      );
    } else if (accuracy >= 55) {
      return (
        label: 'Avanzado',
        color: AppColors.purpleLight,
        icon: Icons.trending_up,
      );
    }
    return (label: 'Novato', color: AppColors.textMuted, icon: Icons.person);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF12042A),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: AppColors.backgroundGradient,
          ),
        ),
        child: SafeArea(
          child: FutureBuilder<List<GameScore>>(
            future: futureScores,
            builder: (context, snapshot) {
              // ── Estados de carga y error ─────────────────────────────────
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(
                    color: AppColors.purpleLight,
                  ),
                );
              }

              if (snapshot.hasError) {
                return const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.error_outline,
                        color: AppColors.textSecondary,
                        size: 48,
                      ),
                      SizedBox(height: 12),
                      Text(
                        'Error cargando estadísticas',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                );
              }

              final scores = snapshot.data ?? [];

              if (scores.isEmpty) {
                return const Center(
                  child: Text(
                    'Todavía no hay partidas',
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 18,
                    ),
                  ),
                );
              }

              _animController.forward();

              // ── Cálculo de métricas ──────────────────────────────────────
              final totalGames = scores.length;
              final totalPoints = scores.fold(0, (s, x) => s + x.points);
              final avgPoints = totalPoints / totalGames;
              final bestScore = scores
                  .map((e) => e.points)
                  .reduce((a, b) => a > b ? a : b);
              final totalCorrect = scores.fold(
                0,
                (s, x) => s + x.correctAnswers,
              );
              final totalRounds = scores.fold(0, (s, x) => s + x.totalRounds);
              final globalAccuracy = totalRounds > 0
                  ? (totalCorrect / totalRounds) * 100
                  : 0.0;

              final tiempos = scores.map((x) => x.avgResponseTimeMs).toList();
              final avgTiempo =
                  tiempos.reduce((a, b) => a + b) / tiempos.length;
              final mejorTiempo = tiempos.reduce((a, b) => a < b ? a : b);
              final peorTiempo = tiempos.reduce((a, b) => a > b ? a : b);

              final desviacion = sqrt(
                scores
                        .map((x) => pow(x.points - avgPoints, 2))
                        .reduce((a, b) => a + b) /
                    totalGames,
              );

              final accuracies = scores.map(
                (x) => x.totalRounds > 0
                    ? (x.correctAnswers / x.totalRounds) * 100
                    : 0.0,
              );
              final mejorAccuracy = accuracies.reduce((a, b) => a > b ? a : b);
              final mejorAccuracyPartida =
                  scores[accuracies.toList().indexOf(mejorAccuracy)];

              final maxRondasPartida = scores.reduce(
                (a, b) => b.totalRounds > a.totalRounds ? b : a,
              );
              final mejora = scores.last.points - scores.first.points;
              final mejorRacha = (totalCorrect / totalGames).round();

              final nivel = _nivel(globalAccuracy);

              // ── UI ───────────────────────────────────────────────────────
              return FadeTransition(
                opacity: _fadeAnim,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── Botón volver ─────────────────────────────────────
                      Align(
                        alignment: Alignment.centerLeft,
                        child: GestureDetector(
                          onTap: () => Navigator.of(context).pop(),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.cardBackground,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: AppColors.cardBorder,
                                width: 0.5,
                              ),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.arrow_back_ios_new_rounded,
                                  color: AppColors.textSecondary,
                                  size: 14,
                                ),
                                SizedBox(width: 6),
                                Text(
                                  'Volver',
                                  style: TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      ProfileHeader(
                        username: widget.user.username,
                        totalGames: totalGames,
                        nivel: nivel,
                      ),

                      const SizedBox(height: 28),

                      // ── Resumen general ──────────────────────────────────
                      const SectionLabel('Resumen general'),
                      const SizedBox(height: 12),
                      GridView.count(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 1.25,
                        children: [
                          StatCard(
                            icon: Icons.emoji_events_rounded,
                            value: bestScore.toString(),
                            label: 'Mejor puntuación',
                            accent: AppColors.accentGold,
                          ),
                          StatCard(
                            icon: Icons.bar_chart_rounded,
                            value: avgPoints.toStringAsFixed(0),
                            label: 'Media de puntos',
                            accent: AppColors.purpleLight,
                          ),
                          StatCard(
                            icon: Icons.gps_fixed_rounded,
                            value: '${globalAccuracy.toStringAsFixed(1)}%',
                            label: 'Precisión global',
                            accent: AppColors.accentGreen,
                          ),
                          StatCard(
                            icon: Icons.sports_esports_rounded,
                            value: totalGames.toString(),
                            label: 'Partidas jugadas',
                            accent: AppColors.accentBlue,
                          ),
                        ],
                      ),

                      const SizedBox(height: 28),

                      // ── Velocidad de respuesta ───────────────────────────
                      const SectionLabel('Velocidad de respuesta'),
                      const SizedBox(height: 12),
                      DetailCard(
                        child: Column(
                          children: [
                            BarRow(
                              label: 'Media',
                              value: '${avgTiempo.toStringAsFixed(0)} ms',
                              ratio: avgTiempo / peorTiempo,
                              color: AppColors.accentIndigo,
                            ),
                            const SizedBox(height: 14),
                            BarRow(
                              label: 'Mejor tiempo',
                              value: '${mejorTiempo.toStringAsFixed(0)} ms',
                              ratio: mejorTiempo / peorTiempo,
                              color: AppColors.accentGreen,
                            ),
                            const SizedBox(height: 14),
                            BarRow(
                              label: 'Peor tiempo',
                              value: '${peorTiempo.toStringAsFixed(0)} ms',
                              ratio: 1.0,
                              color: AppColors.accentOrange,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // ── Respuestas ───────────────────────────────────────
                      const SectionLabel('Respuestas'),
                      const SizedBox(height: 12),
                      DetailCard(
                        child: Column(
                          children: [
                            StatRow(
                              label: 'Total correctas',
                              value: '$totalCorrect',
                            ),
                            StatRow(
                              label: 'Total rondas',
                              value: '$totalRounds',
                            ),
                            StatRow(
                              label: 'Racha media estimada',
                              value: '~$mejorRacha seguidas',
                            ),
                            StatRow(
                              label: 'Partida más precisa',
                              value:
                                  '${mejorAccuracy.toStringAsFixed(1)}% (${mejorAccuracyPartida.pin})',
                              isLast: true,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // ── Consistencia y progresión ────────────────────────
                      const SectionLabel('Consistencia y progresión'),
                      const SizedBox(height: 12),
                      DetailCard(
                        child: Column(
                          children: [
                            StatRow(
                              label: 'Puntos totales',
                              value: totalPoints.toString(),
                            ),
                            StatRow(
                              label: 'Desviación estándar',
                              value: '±${desviacion.toStringAsFixed(0)} pts',
                            ),
                            StatRow(
                              label: 'Partida con más rondas',
                              value:
                                  '${maxRondasPartida.totalRounds} rondas (${maxRondasPartida.pin})',
                            ),
                            StatRow(
                              label: 'Mejora (últ. vs prim.)',
                              value: '${mejora >= 0 ? '+' : ''}$mejora pts',
                              valueColor: mejora >= 0
                                  ? AppColors.accentGreen
                                  : AppColors.accentRed,
                              isLast: true,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
