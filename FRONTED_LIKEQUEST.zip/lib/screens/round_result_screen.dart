import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/game_loop_controller.dart';
import '../services/scores_service.dart';

class RoundResultScreen extends StatefulWidget {
  final String pin;
  final String currentUsername;

  const RoundResultScreen({
    super.key,
    required this.pin,
    required this.currentUsername,
  });

  @override
  State<RoundResultScreen> createState() => _RoundResultScreenState();
}

class _RoundResultScreenState extends State<RoundResultScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;

  final ScoresService _scoresService = ScoresService(
    baseUrl: 'http://localhost:8080',
  );
  List<RemotePlayerScore> _scores = [];

  @override
  void initState() {
    super.initState();

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _scaleAnim = CurvedAnimation(
      parent: _animController,
      curve: Curves.elasticOut,
    ).drive(Tween(begin: 0.5, end: 1.0));
    _fadeAnim = CurvedAnimation(
      parent: _animController,
      curve: Curves.easeIn,
    ).drive(Tween(begin: 0.0, end: 1.0));

    _animController.forward();
    _uploadAndLoad();

    // Auto-avanza después de 4 segundos
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) context.read<GameLoopController>().nextRound();
    });
  }

  Future<void> _uploadAndLoad() async {
    final ctrl = context.read<GameLoopController>();
    final localScore = ctrl.getScore(widget.currentUsername);

    // 1. Sube la puntuación actualizada del jugador local
    if (localScore != null) {
      await _scoresService.saveScore(
        pin: widget.pin,
        username: widget.currentUsername,
        points: localScore.totalPoints,
        correctAnswers: localScore.correctAnswers,
        totalRounds: ctrl.rounds.length,
        avgResponseTimeMs: localScore.averageResponseTime,
      );
    }

    // 2. Carga el ranking actualizado desde la BD
    final scores = await _scoresService.getScores(widget.pin);
    if (mounted) setState(() => _scores = scores);
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<GameLoopController>();
    final correct = ctrl.lastAnswerCorrect ?? false;
    final points = ctrl.lastPointsEarned;
    final correctAnswer = ctrl.currentRound.correctAnswer;

    // Usa BD si ya cargó, si no usa puntuación local como fallback
    final scores = _scores.isNotEmpty
        ? _scores
        : ctrl.sortedScores
              .map(
                (s) => RemotePlayerScore(
                  username: s.username,
                  points: s.totalPoints,
                  correctAnswers: s.correctAnswers,
                  totalRounds: ctrl.rounds.length,
                  avgResponseTimeMs: s.averageResponseTime,
                ),
              )
              .toList();

    return Scaffold(
      backgroundColor: correct
          ? const Color(0xFF0D2A0D)
          : const Color(0xFF2A0D0D),
      body: SafeArea(
        child: Column(
          children: [
            // ── Resultado principal ──────────────────────────────────
            Expanded(
              flex: 2,
              child: SingleChildScrollView(
                child: FadeTransition(
                  opacity: _fadeAnim,
                  child: ScaleTransition(
                    scale: _scaleAnim,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Icono más pequeño
                          Icon(
                            correct ? Icons.check_circle : Icons.cancel,
                            color: correct
                                ? const Color(0xFF4CAF50)
                                : const Color(0xFFF44336),
                            size: 60, // ← era 80
                          ),
                          const SizedBox(height: 8), // ← era 16
                          Text(
                            correct ? '¡CORRECTO!' : 'INCORRECTO',
                            style: TextStyle(
                              color: correct
                                  ? const Color(0xFF4CAF50)
                                  : const Color(0xFFF44336),
                              fontSize: 26, // ← era 32
                              fontWeight: FontWeight.bold,
                              letterSpacing: 3,
                            ),
                          ),
                          const SizedBox(height: 6), // ← era 8
                          Text(
                            'Era: $correctAnswer',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 16,
                            ), // ← era 18
                          ),
                          const SizedBox(height: 12), // ← era 20
                          if (correct)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 8,
                              ), // ← era 24/12
                              decoration: BoxDecoration(
                                color: const Color(0xFF4CAF50).withOpacity(0.2),
                                borderRadius: BorderRadius.circular(30),
                                border: Border.all(
                                  color: const Color(0xFF4CAF50),
                                  width: 1.5,
                                ),
                              ),
                              child: Text(
                                '+$points pts',
                                style: const TextStyle(
                                  color: Color(0xFF4CAF50),
                                  fontSize: 22, // ← era 28
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // ── Ranking desde BD ─────────────────────────────────────
            Expanded(
              flex: 3,
              child: FadeTransition(
                opacity: _fadeAnim,
                child: Column(
                  children: [
                    const Text(
                      'CLASIFICACIÓN',
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 12,
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Expanded(
                      child: scores.isEmpty
                          ? const Center(
                              child: CircularProgressIndicator(
                                color: Color(0xFF6C63FF),
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                              itemCount: scores.length,
                              itemBuilder: (context, index) {
                                final score = scores[index];
                                final isMe =
                                    score.username == widget.currentUsername;
                                final medals = ['🥇', '🥈', '🥉'];
                                final medal = index < 3
                                    ? medals[index]
                                    : '${index + 1}.';

                                return Container(
                                  margin: const EdgeInsets.symmetric(
                                    vertical: 4,
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 10,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isMe
                                        ? const Color(
                                            0xFF6C63FF,
                                          ).withOpacity(0.2)
                                        : Colors.white.withOpacity(0.05),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: isMe
                                          ? const Color(
                                              0xFF6C63FF,
                                            ).withOpacity(0.5)
                                          : Colors.transparent,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        width: 32,
                                        child: Text(
                                          medal,
                                          style: const TextStyle(fontSize: 18),
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Flexible(
                                              child: Text(
                                                score.username,
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 15,
                                                ),
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                            if (isMe) ...[
                                              const SizedBox(width: 6),
                                              Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      horizontal: 6,
                                                      vertical: 2,
                                                    ),
                                                decoration: BoxDecoration(
                                                  color: const Color(
                                                    0xFF6C63FF,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(4),
                                                ),
                                                child: const Text(
                                                  'TÚ',
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ),
                                      Text(
                                        '${score.points} pts',
                                        style: const TextStyle(
                                          color: Color(0xFF6C63FF),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(
                        ctrl.isLastRound
                            ? 'Última ronda...'
                            : 'Siguiente ronda en unos segundos...',
                        style: const TextStyle(
                          color: Colors.white38,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
