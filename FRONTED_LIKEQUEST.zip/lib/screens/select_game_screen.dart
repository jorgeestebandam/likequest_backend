import 'package:flutter/material.dart';
import 'package:like_quest_flutter/components/carruselFrases_widget.dart';
import 'package:like_quest_flutter/components/game_selector.dart';
import 'package:like_quest_flutter/components/logoContainer.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/screens/profile_screen.dart';

class SelectGameScreen extends StatefulWidget {
  final User user;
  const SelectGameScreen({super.key, required this.user});

  @override
  State<SelectGameScreen> createState() => _SelectGameScreenState();
}

class _SelectGameScreenState extends State<SelectGameScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // Imagen de fondo
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/fondo2.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        // Todo el contenido encima de la imagen
        child: SafeArea(
          child: Stack(
            children: [
              // =========================
              // BOTÓN PERFIL
              // =========================
              Positioned(
                top: 10,
                right: 10,

                child: IconButton(
                  icon: const Icon(Icons.person, color: Colors.white, size: 34),

                  onPressed: () {
                    Navigator.push(
                      context,

                      MaterialPageRoute(
                        builder: (_) => ProfileScreen(user: widget.user),
                      ),
                    );
                  },
                ),
              ),

              // =========================
              // CONTENIDO PRINCIPAL
              // =========================
              Column(
                mainAxisAlignment: MainAxisAlignment.start,

                children: [
                  // LOGO
                  LogoWidget(),

                  // ESPACIO
                  SizedBox(height: 20),

                  // FRASES
                  CarruselFrases(),

                  Expanded(
                    child: Align(
                      alignment: const Alignment(0, 0.1),

                      child: GameSelector(user: widget.user),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
