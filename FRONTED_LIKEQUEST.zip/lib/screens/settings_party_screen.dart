import 'package:flutter/material.dart';
import 'package:like_quest_flutter/components/settings_party_widget.dart';
import 'package:like_quest_flutter/core/color.dart';

class SeetingPartyScreen extends StatelessWidget {
  final String pin;
  const SeetingPartyScreen({super.key,required this.pin});

  @override
  // construcción de la pantalla de configuración de la partida , 
  //que llama al widget correspondiente
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundApp,
      body: SafeArea(
        child: SeetingPartyWidget(
          pin: pin,
        ),
      ),
    );
  }
}
