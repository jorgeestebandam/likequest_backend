import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../controllers/game_loop_controller.dart';

class VideoRoundScreen extends StatefulWidget {
  const VideoRoundScreen({super.key});

  @override
  State<VideoRoundScreen> createState() => _VideoRoundScreenState();
}

class _VideoRoundScreenState extends State<VideoRoundScreen>
    with SingleTickerProviderStateMixin {
  VideoPlayerController? _videoController;
  late AnimationController _progressController;
  bool _videoError = false;
  bool _hasEnded = false;

  // ✅ Guardamos el índice de la ronda que está cargada actualmente
  int _loadedRoundIndex = -1;

  static const int _maxVideoDuration = 20;

  @override
  void initState() {
    super.initState();
    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: _maxVideoDuration),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initVideo();
      // ✅ Escuchamos cambios del controller para detectar nueva ronda
      context.read<GameLoopController>().addListener(_onGameStateChanged);
    });
  }

  // ✅ Se dispara cada vez que el GameLoopController llama a notifyListeners()
  void _onGameStateChanged() {
    if (!mounted) return;
    final ctrl = context.read<GameLoopController>();

    // Solo recargamos si estamos en fase video Y la ronda ha cambiado
    if (ctrl.phase == GamePhase.video &&
        ctrl.currentRoundIndex != _loadedRoundIndex) {
      _initVideo();
    }
  }

  Future<void> _initVideo() async {
    if (!mounted) return;

    final controller = context.read<GameLoopController>();
    final roundIndex = controller.currentRoundIndex;
    final url = controller.currentRound.videoUrl;

    // ✅ Evita recargar si ya está cargado este índice
    if (roundIndex == _loadedRoundIndex) return;

    _hasEnded = false;
    _videoError = false;
    _loadedRoundIndex = roundIndex;

    // Limpia el controller anterior
    _videoController?.removeListener(_onVideoProgress);
    await _videoController?.dispose();
    _videoController = null;

    if (mounted) setState(() {});

    try {
      final vc = VideoPlayerController.networkUrl(Uri.parse(url));
      await vc.initialize();

      if (!mounted) return;

      _videoController = vc;
      setState(() {});

      _videoController!.addListener(_onVideoProgress);
      _videoController!.play();
      _progressController
        ..reset()
        ..forward();

      Future.delayed(const Duration(seconds: _maxVideoDuration), _onVideoEnd);
    } catch (e) {
      if (!mounted) return;
      setState(() => _videoError = true);
      Future.delayed(const Duration(seconds: 3), _onVideoEnd);
    }
  }

  void _onVideoProgress() {
    if (_videoController == null) return;
    final pos = _videoController!.value.position;
    final dur = _videoController!.value.duration;
    if (dur.inMilliseconds > 0 && pos >= dur) {
      _onVideoEnd();
    }
  }

  void _onVideoEnd() {
    if (_hasEnded) return;
    _hasEnded = true;
    if (!mounted) return;
    _videoController?.removeListener(_onVideoProgress);
    context.read<GameLoopController>().onVideoFinished();
  }

  @override
  void dispose() {
    // ✅ Quitamos el listener del controller al destruir el widget
    context.read<GameLoopController>().removeListener(_onGameStateChanged);
    _videoController?.removeListener(_onVideoProgress);
    _videoController?.dispose();
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<GameLoopController>();
    final round = controller.currentRound;

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A2E),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFF6C63FF),
                        width: 1.5,
                      ),
                    ),
                    child: Text(
                      'RONDA ${round.roundNumber}',
                      style: const TextStyle(
                        color: Color(0xFF6C63FF),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  Text(
                    '${controller.currentRoundIndex + 1} / ${controller.rounds.length}',
                    style: const TextStyle(color: Colors.white54, fontSize: 14),
                  ),
                ],
              ),
            ),

            // ── Barra de progreso ────────────────────────────────────
            AnimatedBuilder(
              animation: _progressController,
              builder: (_, __) => LinearProgressIndicator(
                value: 1 - _progressController.value,
                backgroundColor: const Color(0xFF1A1A2E),
                valueColor: AlwaysStoppedAnimation<Color>(
                  Color.lerp(
                    const Color(0xFF6C63FF),
                    const Color(0xFFFF6584),
                    _progressController.value,
                  )!,
                ),
                minHeight: 4,
              ),
            ),

            // ── Vídeo ────────────────────────────────────────────────
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: _buildVideoWidget(),
                ),
              ),
            ),

            // ── Footer ──────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.only(bottom: 24),
              child: Text(
                '¿Quién ha dado like a este vídeo?',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.6),
                  fontSize: 16,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoWidget() {
    if (_videoError) {
      return Container(
        color: const Color(0xFF1A1A2E),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.videocam_off, color: Colors.white38, size: 48),
              SizedBox(height: 12),
              Text(
                'Error cargando vídeo',
                style: TextStyle(color: Colors.white38),
              ),
            ],
          ),
        ),
      );
    }

    if (_videoController == null || !_videoController!.value.isInitialized) {
      return Container(
        color: const Color(0xFF1A1A2E),
        child: const Center(
          child: CircularProgressIndicator(color: Color(0xFF6C63FF)),
        ),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: _videoController!.value.size.width,
            height: _videoController!.value.size.height,
            child: VideoPlayer(_videoController!),
          ),
        ),
      ],
    );
  }
}
