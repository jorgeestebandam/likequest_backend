import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:like_quest_flutter/configuations/url.dart';
import 'package:like_quest_flutter/models/User.dart';
import 'package:like_quest_flutter/screens/conditions_screen.dart';

class AuthService {
  // Como estás usando CHROME, usamos localhost.
  // Si volvieras al emulador de Android, cambia esto a 10.0.2.2
  static const String _baseUrl = url.baseNgrock;

  // Servicio encargado de la autenticación y comunicación con el backend
  Future<AuthResponse> verificarUsername(String username) async {
    // Verifica si el username existe y obtiene los datos necesarios , sino existe devuelve error
    if (username.trim().isEmpty) {
      return AuthResponse(
        success: false,
        error: 'empty_username',
        message: 'Por favor, escribe un nombre de usuario.',
      );
    }
    // Construimos la URL del endpoint /login
    final url = Uri.parse('$_baseUrl/login');

    try {
      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json',
            'ngrok-skip-browser-warning': 'true',},
            body: jsonEncode({'username': username}),
          )
          .timeout(const Duration(seconds: 60)); // Selenium  tarda en responder

      // Decodificamos la respuesta
      final Map<String, dynamic> data = jsonDecode(response.body);
      print("Respuesta real del servidor: $data");

      // --- RESPUESTA CORRECTA ---
      if (response.statusCode == 200) {
        // 1. Verificamos si es público (Java envía "true" o "false" como String)
        final String isPublicStr =
            data['isPublic']?.toString().toLowerCase() ?? 'false';
        final bool esPublico = isPublicStr == 'true';

        // Si la cuenta es privada, lo enviamos como error a la pntalla de login principal
        if (!esPublico) {
          return AuthResponse(
            success: false,
            error: 'private_account',
            message: 'Esta cuenta es privada en TikTok.',
          );
        }

        //  Extraer la lista de vídeos con "me gusta"
        final List<dynamic> videosRaw = data['urlVideosLiked'] ?? [];
        // Si no hay vídeos públicos, se devuelve error en la clase
        if (videosRaw.isEmpty) {
          return AuthResponse(
            success: false,
            error: 'no_videos',
            message:
                'No se encontraron vídeos públicos en tu sección de "Me gusta".',
          );
        }
        // Convertimos la lista dinámica a una lista de Strings
        final List<String> urlVideos = videosRaw
            .map((v) => v.toString())
            .toList();

        //  Construimos el objeto User con los datos obtenidos y lo devolvemos
        return AuthResponse(
          success: true,
          user: User(username: username, urlVideos: urlVideos),
        );
      } else if (response.statusCode == 404) {
        return AuthResponse(
          success: false,
          error: 'not_found',
          message: 'El usuario no existe en TikTok.',
        );
      } else {
        return AuthResponse(
          success: false,
          error: 'server_error',
          message: 'Error del servidor: ${response.statusCode}',
        );
      }
    } catch (e) {
      print('Error de conexión: $e');
      return AuthResponse(
        success: false,
        error: 'connection_error',
        message:
            'No se pudo conectar al servidor. Revisa si tu backend está corriendo.',
      );
    }
  }

  // Método para mostrar las alertas rápidamente
  void manejarErrorLogin(BuildContext context, AuthResponse response) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(
          'Atención',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: Text(response.message ?? 'Error desconocido'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Aceptar'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ConditionsScreen()),
              );
            },
            child: const Text('Ver condiciones'),
          ),
        ],
      ),
    );
  }
}

class AuthResponse {
  final bool success;
  final String? error;
  final String? message;
  final User? user;

  AuthResponse({required this.success, this.error, this.message, this.user});
}
