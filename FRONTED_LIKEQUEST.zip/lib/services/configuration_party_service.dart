// Permite convertir objetos Dart a JSON y viceversa
import 'dart:convert';

// Paquete para realizar peticiones HTTP
import 'package:http/http.dart' as http;
import 'package:like_quest_flutter/configuations/url.dart';

// Servicio encargado de actualizar la configuración de una partida
class ConfigurationPartyService {
  // URL base del backend para la gestión de partidas
  final String _baseUrl = '${url.baseNgrock}/party';

  // --- MÉTODO PARA ACTUALIZAR LA CONFIGURACIÓN DE LA PARTIDA ---
  Future<void> updatePartyConfig({
    required String pin,          // PIN de la sala
    required int numberRounds,    // Número de rondas
    required int choiceTime,      // Duración de cada ronda
    required int maxUsers,        // Máximo de jugadores permitidos
    required bool joinLater,      // Permitir unirse tarde o no
  }) async {
    // Endpoint específico para actualizar la configuración
    final url = Uri.parse('$_baseUrl/config');

    // Petición PUT al backend con los datos en formato JSON
    final response = await http.put(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        "pin": pin,
        "number_rounds": numberRounds,
        "choice_time": choiceTime,
        "max_users": maxUsers,
        "join_later": joinLater,
      }),
    );

    // Si la respuesta es correcta (2xx), no se devuelve nada
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return; // Configuración actualizada correctamente
    }

    // Si hay error, se decodifica el mensaje del backend
    final errorData = jsonDecode(response.body);

    // Manejo de errores según el código HTTP
    switch (response.statusCode) {
      // Error de validación o datos incorrectos
      case 400:
      case 422:
        throw Exception(
          errorData['message'] ??
              'No se puede establecer ese límite de jugadores, ya se ha superado',
        );

      // Error interno del servidor
      case 500:
        throw Exception(
          errorData['message'] ?? 'Error interno de base de datos',
        );

      // Cualquier otro error no esperado
      default:
        throw Exception(
          'Error inesperado (${response.statusCode})',
        );
    }
  }
}
