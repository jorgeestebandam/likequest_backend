import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:like_quest_flutter/configuations/url.dart';
import 'package:like_quest_flutter/models/GameInitModel.dart';


class GameSetUpService {
  final String baseUrl = url.baseNgrock;

  Future<GameInitModel?> cargarPartida(String pin) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/party/$pin/init'),
      );

      print("Status: ${response.statusCode}"); 
      print("Body: ${response.body}");     

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return GameInitModel.fromJson(data);
      }
      return null;
    } catch (e) {
      print("Error en cargarPartida: $e");
      return null;
    }
  }

  Future<GameInitModel?> obtenerPartidaLista(String pin) async {
  try {
    final response = await http.get(Uri.parse('$baseUrl/party/$pin/status'));
    if (response.statusCode == 200) {
      return GameInitModel.fromJson(jsonDecode(response.body));
    }
    return null; // 
  } catch (e) {
    return null;
  }
}
}