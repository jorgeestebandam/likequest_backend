import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:like_quest_flutter/configuations/url.dart';
import 'package:like_quest_flutter/models/User.dart';

// Servicio encargado de unir un usuario a una partida existente
class JoinPartyService {
  // URL base del backend para gestión de partidas
  final String _baseUrl = '${url.baseNgrock}/party';

  // --- MÉTODO PARA UNIRSE A UNA PARTIDA EXISTENTE ---
  Future<void> joinParty({
    required String pin, // PIN de la sala a la que se quiere unir
    required User user, // Usuario que quiere unirse
  }) async {
    // Endpoint específico para unirse a partidas
    final url = Uri.parse('$_baseUrl/join');
    // Petición POST con los datos del usuario y PIN en formato JSON
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        "pin": pin,
        "user": user.toJson(), // convierte el usuario a JSON
      }),
    );

    // Si la respuesta es 200, todo correcto, no hay retorno necesario
    if (response.statusCode == 200) {
      return;
    }

    // Decodifica el error enviado por el backend
    final Map<String, dynamic> errorData = jsonDecode(response.body);

    // Manejo de errores según el código HTTP
    switch (response.statusCode) {
      case 404:
        throw Exception(
          errorData['message'] ?? 'No se ha encontrado partida con ese PIN',
        );
      case 409:
        throw Exception(errorData['message'] ?? 'La partida ha finalizado');
      case 403:
        throw Exception(
          errorData['message'] ??
              'La partida está en curso, pero no se permite unirse más tarde',
        );
      case 405:
        throw Exception(
          errorData['message'] ?? 'Ya existe ese usuario en la partida',
        );
      case 406:
        throw Exception(
          errorData['message'] ??
              'Ya se alcanzó el límite de jugadores de esta partida',
        );
      case 500:
      default:
        throw Exception(
          errorData['message'] ?? 'Error interno de base de datos',
        );
    }
  }

  Future<void> leaveParty({required String pin, required User user}) async {
    final url = Uri.parse('$_baseUrl/leave');

    // Petición DELETE al backend
    final response = await http.delete(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({"pin": pin, "user": user.toJson()}),
    );
    // Solo imprimir en consola si falla, no lanzar excepción
    if (response.statusCode >= 400) {
      print('Error al abandonar la partida: ${response.statusCode}');
    }
  }
}
