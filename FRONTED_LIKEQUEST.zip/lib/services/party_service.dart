import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:like_quest_flutter/configuations/url.dart';
import 'package:like_quest_flutter/models/User.dart';

class PartyService {
  // URL base del servicio de partidas
  final String _baseUrl = '${url.baseNgrock}/party';

  // Método para crear una nueva partida
  Future<Map<String, dynamic>> createParty(User user) async {
    final url = Uri.parse('$_baseUrl/create');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      // Le pasamos el usuario logueado al backend como cuerpo de la petición
      body: jsonEncode(user.toJson()),
    );
    // Si esta correngo correctamente, devolvemos los datos de la partida (pin, creador)
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      return data;
    } else {
      // Si hay un error, lanzamos una excepción
      throw Exception('Error al crear la partida');
    }
  }

  // Método para eliminar una partida por su pin
  Future<Map<String, dynamic>> deleteParty(String pin) async {
    final url = Uri.parse('$_baseUrl/$pin'); // Pin en la URL

    final response = await http.delete(
      url,
      headers: {'Content-Type': 'application/json'}, // opcional
    );
    // Si la eliminación es exitosa, devolvemos la respuesta del backend
    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
      // Si la partida no existe, lanzamos una excepción que viene desde el backend
    } else if (response.statusCode == 404) {
      throw Exception('Partida no encontrada');
      // Otros errores
    } else {
      throw Exception('Error al eliminar la partida: ${response.statusCode}');
    }
  }

  // Método para obtener la lista de jugadores en una partida para mostrar
  //en la pantalla de configuración
  Future<List<String>> fetchJugadores(String pin) async {
    final url = Uri.parse('$_baseUrl/$pin/players');
    print("Llamando a: $url"); //

    final response = await http.get(url);

    // Si la petición es correcta, devolvemos la lista de jugadores
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      // Supongamos que backend devuelve: { "jugadores": ["Alice", "Bob"] }
      return List<String>.from(data['jugadores']);
      // Si hay un error, lanzamos una excepción
    } else {
      throw Exception('Error al cargar jugadores');
    }
  }

  Future<String> getCreatorParty(String pin) async {
    final url = Uri.parse('$_baseUrl/$pin/creator');

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      return data['creator'] as String;
    } else if (response.statusCode == 404) {
      throw Exception('Partida no encontrada');
    } else {
      throw Exception('Error al cargar creador');
    }
  }

  Future<void> iniciarPartida(String pin) async {
    final url = Uri.parse('$_baseUrl/$pin/start');
    final response = await http.put(url);
    if (response.statusCode != 204) {
      throw Exception("Error al iniciar la partida");
    }
  }

  Future<String> getEstadoPartida(String pin) async {
    final url = Uri.parse('$_baseUrl/$pin/state');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      return data['estado'] as String;
    } else {
      throw Exception('Error al obtener estado');
    }
  }
}
