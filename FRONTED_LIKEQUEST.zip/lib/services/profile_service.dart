import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:like_quest_flutter/configuations/url.dart';
import 'package:like_quest_flutter/models/game_score.dart';

class ProfileService {
  final String baseUrl = url.baseNgrock;

  Future<List<GameScore>> getUserScores(
      String username) async {

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/profile/$username'),
      );

      if (response.statusCode == 200) {

        final List data =
            jsonDecode(response.body);

        return data
            .map((e) => GameScore.fromJson(e))
            .toList();
      }

      return [];

    } catch (e) {
      print("Error carga perfil de usuario: $e");
      return [];
    }
  }
}