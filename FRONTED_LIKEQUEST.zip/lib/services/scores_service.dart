import 'dart:convert';
import 'package:http/http.dart' as http;

// ── Modelo ───────────────────────────────────────────────────────────────────

class RemotePlayerScore {
  final String username;
  final int points;
  final int correctAnswers;
  final int totalRounds;
  final double avgResponseTimeMs;

  RemotePlayerScore({
    required this.username,
    required this.points,
    required this.correctAnswers,
    required this.totalRounds,
    required this.avgResponseTimeMs,
  });

  factory RemotePlayerScore.fromJson(Map<String, dynamic> json) {
    return RemotePlayerScore(
      username: json['username'],
      points: json['points'],
      correctAnswers: json['correctAnswers'],
      totalRounds: json['totalRounds'],
      avgResponseTimeMs: (json['avgResponseTimeMs'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
        'username': username,
        'points': points,
        'correctAnswers': correctAnswers,
        'totalRounds': totalRounds,
        'avgResponseTimeMs': avgResponseTimeMs,
      };
}

// ── Servicio ─────────────────────────────────────────────────────────────────


class ScoresService {
  final String baseUrl;

  ScoresService({required this.baseUrl});

  /// Envía la puntuación del jugador local al backend
  Future<bool> saveScore({
    required String pin,
    required String username,
    required int points,
    required int correctAnswers,
    required int totalRounds,
    required double avgResponseTimeMs,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/scores/$pin'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'points': points,
          'correctAnswers': correctAnswers,
          'totalRounds': totalRounds,
          'avgResponseTimeMs': avgResponseTimeMs,
        }),
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  /// Obtiene la clasificación completa de todos los jugadores
  Future<List<RemotePlayerScore>> getScores(String pin) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/api/scores/$pin'));
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((e) => RemotePlayerScore.fromJson(e)).toList();
      }
    } catch (e) {
      // ignorar
    }
    return [];
  }

  /// Borra las puntuaciones al reiniciar la partida
  Future<void> deleteScores(String pin) async {
    try {
      await http.delete(Uri.parse('$baseUrl/api/scores/$pin'));
    } catch (_) {}
  }
}